<?php

$conn = mysqli_connect('localhost', 'root', '', 'contact_db') or die('connection failed');

if (isset($_POST['submit'])) {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $age = mysqli_real_escape_string($conn, $_POST['age']);
    $gender = $_POST['gender'];
    $date = $_POST['date'];

    $insert = mysqli_query($conn, "INSERT INTO `contact_form`(name, email, age, gender, date) VALUES('$name','$email','$age', '$gender', '$date')") or die('query failed');

    if ($insert) {
        $message[] = 'appointment made successfully!';
    } else {
        $message[] = 'appointment failed';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Website</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong>MK</strong> hospital Kandy</a>

        <nav class="navbar">
            <a href="#home">home</a>
            <a href="#about">about</a>
            <a href="#services">services</a>
            <a href="#doctors">doctors</a>
            <a href="#appointment">appointment</a>
            <a href="#review">review</a>
            <a href="#blogs">blogs</a>
        </nav>

        <div id="menu-btn" class="fas fa-bars"></div>

    </header>

    <!-- header section ends -->

    <!-- home section starts  -->

    <section class="home" id="home">

        <div class="content">
            <h3>MAKING HEALTH CARE BETTER TOGETHER</h3>
            <p> A person who has good physical health is likely to have bodily functions and processes working at their peak. We offer International patients the best of care and their families top class accommodation in order to reduce the hassle of their hospital visit and aid in their recovery.</p>
            <a href="#appointment" class="btn"> appointment us <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="image">
            <img src="image/home-img.svg" alt="">
        </div>

    </section>

    <!-- home section ends -->

    <!-- icons section starts  -->

    <section class="icons-container">

        <div class="icons">
            <i class="fas fa-user-md"></i>
            <h3>40+</h3>
            <p>doctors at work</p>
        </div>

        <div class="icons">
            <i class="fas fa-users"></i>
            <h3>430+</h3>
            <p>satisfied patients</p>
        </div>

        <div class="icons">
            <i class="fas fa-procedures"></i>
            <h3>160+</h3>
            <p>bed facility</p>
        </div>

        <div class="icons">
            <i class="fas fa-hospital"></i>
            <h3>30+</h3>
            <p>available hospitals</p>
        </div>

    </section>

    <!-- icons section ends -->

    <!-- about section starts  -->

    <section class="about" id="about">

        <h1 class="heading"> <span>about</span> us </h1>

        <div class="row">

            <div class="content">
                <h3>We’re committed to providing high-quality medical care</h3>
                <p>All we care is your health and well being hence, we, at MK Hospital treat all our patients with full care, assisting all their needs while ensuring their health and fitness. Here, patients have access to all medical and surgical sub-specialties within a single institution, empowering the medical team to address all the patient’s health needs and treat the whole person.</p>
                <p>We are committed to providing quality health care for all since our goal is to inspire and empower you and our community to engage in the pursuit of health and well-being for life. Our expertise team and leading medical practitioners are dedicated to providing their service in every day for you.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="image">
                <img src="image/about-img.svg" alt="">
            </div>

        </div>

    </section>

    <!-- about section ends -->

    <!-- Lab section starts -->

    <section class="home" id="home">

        <div class="content">
            <h3>LAB NETWORK</h3>
            <p> MK Hospital Laboratory Services is accredited with ISO 15189:2022 standards. We aspire to provide the best clinical outcomes in the medical industry by adopting strong clinical standards and supported by passionate, well-trained, committed and motivated staff. Our philosophy will be to have an uncompromising commitment to provide the best customer experience to all patients who patronize our hospitals and laboratories in a high tech and modern environment.</p>
        </div>

    </section>

    <!-- Lab section ends -->

    <!-- Whats new section starts -->

    <section class="home" id="home">

        <div class="content">
            <h3>WHAT’S HAPPENING AT MK HOSPITALS…</h3>
            <p> At Hemas Hospitals there’s never a dull moment. It’s all about happenings with events, celebrations, CSR activities, ceremonies and many more.</p>
        </div>

    </section>

    <!-- Whats new section ends -->

    <!-- services section starts  -->

    <section class="services" id="services">

        <h1 class="heading"> our <span>services</span> </h1>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-notes-medical"></i>
                <h3>ETU</h3>
                <p>Patients who have developed a sudden illness or suffered an injury or accident will be treated in our Emergency Treatment Unit.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="box">
                <i class="fas fa-ambulance"></i>
                <h3>24/7 ambulance</h3>
                <p>We operate a 24-hour ambulance service. All our ambulances are well maintained, spacious and comfortable.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="box">
                <i class="fas fa-user-md"></i>
                <h3>expert doctors</h3>
                <p>Well recognized doctors can be channeled according to their schedules.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="box">
                <i class="fas fa-pills"></i>
                <h3>medicines</h3>
                <p>Our pharmacy is open 24 hours each day of the year. We currently also operate a medicine home delivery service.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="box">
                <i class="fas fa-procedures"></i>
                <h3>bed facility</h3>
                <p>Medihelp has established itself as a provider of inpatient care services of a superior standard. Our inpatient admission facilities are numerous and our patients can select from 4 distinct room types ranging from an economical ward bed to a private air-conditioned room with an attached bathroom.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

            <div class="box">
                <i class="fas fa-heartbeat"></i>
                <h3>total care</h3>
                <p>At MK our focus is to treat individuals and not just illnesses. Providing world-class healthcare and ensuring a high degree of patient satisfaction is priority.</p>
                <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>

        </div>

    </section>
    <!-- services section ends -->

    <!-- Services section starts -->

    <section class="home" id="home">

        <div class="content">
            <h3>Our Services</h3>
            <p> We take care of your preventive and curative healthcare requirements at our state-of-the-art facilities. Collectively, our hospitals can accommodate 190 in-house patients where you can be rest assured of receiving care on par with international standards. Our island wide laboratory services network is well-equipped with the cutting-edge technology, equipment and skilled professionals to provide accurate diagnostic investigations. We’ve purposely built our hospitals to align with international standards and equipped each area with the latest technological advancements. You can visit our Accident and Emergency units any time during the day and night to receive medical or surgical emergency care.</p>
        </div>

    </section>

    <!-- services section ends -->

    <!-- Services section starts -->

    <section class="home" id="home">

        <div class="content">
            <h3>We take care of you! </h3>
            <p> Within the safe confines of our ultra-clean hospital environments, we employ experienced healthcare professionals to care for you. Our medical and support staff is trained to provide compassionate care while paying attention to detail. You and your family members can enjoy the high end comfort of our hospital rooms, designed to help expedite the recovery process.</p>
        </div>

    </section>

    <!-- services section ends -->

    <!-- doctors section starts  -->

    <section class="doctors" id="doctors">

        <h1 class="heading"> our <span>doctors</span> </h1>

        <div class="box-container">

            <div class="box">
                <img src="image/doc-1.jpg" alt="">
                <h3>Dr. S. warunika</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>

                </div>
            </div>

            <div class="box">
                <img src="image/doc-2.jpg" alt="">
                <h3> Dr. F.S. Marleen</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <img src="image/doc-3.jpg" alt="">
                <h3>Dr(Mrs) D. Muthukuda</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <img src="image/doc-4.jpg" alt="">
                <h3>Dr. Sara reeza</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <img src="image/doc-5.jpg" alt="">
                <h3>Dr. D.W. Wariyapola</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <img src="image/doc-6.jpg" alt="">
                <h3>Dr. raaz mohamed</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>

                </div>
            </div>
            <div class="box">
                <img src="image/doc-7.jpg" alt="">
                <h3>Dr. Sheza nish</h3>
                <span>intern doctor</span>
                <div class="share">

                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
            <div class="box">
                <img src="image/doc-8.jpg" alt="">
                <h3>Dr. Jayantha</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
            <div class="box">
                <img src="image/doc-4.jpg" alt="">
                <h3>Dr. Prem zoya</h3>
                <span>expert doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <img src="image/doc-5.jpg" alt="">
                <h3>Dr. S. XYZ</h3>
                <span>training doctor</span>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>

                </div>
            </div>

        </div>

    </section>

    <!-- doctors section ends -->

    <!-- Doctors section starts -->

    <section class="home" id="home">

        <div class="content">
            <h3>Best Clinical Outcomes</h3>
            <p>We pioneered in introducing international hospital accreditation to Sri Lanka by becoming the first internationally accredited hospital chain with the prestigious Australian Council on Healthcare Standards International (ACHSI) accreditation. We adhere to international best practices to ensure safety and the highest levels of clinical outcomes of our patients.</p>
        </div>

    </section>

    <!-- Doctors section ends -->

    <!-- appointmenting section starts   -->

    <section class="appointment" id="appointment">

        <h1 class="heading"> <span>appointment</span> now </h1>

        <div class="row">

            <div class="image">
                <img src="image/appointment-img.svg" alt="">
            </div>

            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <?php
                if (isset($message)) {
                    foreach ($message as $message) {
                        echo '<p class ="message">' . $message . '</p>';
                    }
                }
                ?>

                <h3>book an appointment</h3>
                <input type="text" name="name" placeholder="your name" class="box">
                <p input type="gender" name="gender" class="box"> <select name="gender">
         <option value="male">male</option>
         <option value="female">female</option>
      </select>
                <input type="age" name="age" placeholder="your age" class="box">
                <input type="email" name="email" placeholder="your email" class="box">
                <input type="date" name="date" class="box">
                <input type="submit" name="submit" value="appointment now" class="btn">
            </form>

        </div>

    </section>

    <!-- appointmenting section ends -->

    <!-- review section starts  -->

    <section class="review" id="review">

        <h1 class="heading"> client's <span>review</span> </h1>

        <div class="box-container">

            <div class="box">
                <img src="image/pic-1.jpg" alt="">
                <h3>J. Jayasinghe</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <p class="text">64 year old Professor Lakshman Marasinghe went through an open heart bypass surgery recently and is feeling better than ever. Listen to this heartwarming account of his patient journey!</p>
            </div>

            <div class="box">
                <img src="image/pic-2.jpg" alt="">
                <h3>S. priyasankari</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <p class="text">The daughter of eye surgery patient speaks about her experience at Durdans Hospital and recommends Durdans Hospital for high quality eye care!</p>
            </div>

            <div class="box">
                <img src="image/pic-3.jpg" alt="">
                <h3>K. D. Saranga</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <p class="text">The first ever balloon expandable transcatheter aortic valve implantation (TAVI) – (without open heart surgery) was performed on an 73 year old patient with Ischemic Heart Disease and poor lung function!</p>
            </div>

        </div>

    </section>

    <!-- review section ends -->

    <!-- blogs section starts  -->

    <section class="blogs" id="blogs">

        <h1 class="heading"> our <span>blogs</span> </h1>

        <div class="box-container">

            <div class="box">
                <div class="image">
                    <img src="image/blog-11.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 22 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>Rectal bleeding</h3>
                    <p>Rectal bleeding is the passage of blood from the bottom. Most rectal bleeding is not a cause for concern.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="image/blog-12.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 24 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>Common Health Risks and How to Prevent Them</h3>
                    <p>Winter brings with it a host of health risks that are important for the community to be aware of.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="image/blog-13.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 24 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>Overview, Symptoms and Preventione</h3>
                    <p>Overview: One of the most prevalent illnesses affecting Indians is dengue.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="image/blog-14.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 24 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>Gallstone</h3>
                    <p>The gallbladder is a tiny sac positioned on the right side of the body beneath the liver. Some of the substances found in the gallbladder might harden into one large or multiple tiny stones.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="image/blog-15.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 26 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>PEM Blog and Treatment</h3>
                    <p>Emergency medicine is the name of the game for this information-packed blog. While a lot of the posts deal with children, there’s broader information that can prove helpful for any physician working in the ER.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="image/blog-16.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icon">
                        <a href="#"> <i class="fas fa-calendar"></i> 28 october, 2023 </a>
                        <a href="#"> <i class="fas fa-user"></i> by sumaiyah ashraf </a>
                    </div>
                    <h3>Types, Causes Treatments</h3>
                    <p>What is Arthritis? Arthritis is an inflammation of the joints that can happen to one or more joints at the same time.</p>
                    <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
                </div>
            </div>

        </div>

    </section>

    <!-- blogs section ends -->

    <!-- footer section starts  -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>quick links</h3>
                <a href="#home"> <i class="fas fa-chevron-right"></i> home </a>
                <a href="#about"> <i class="fas fa-chevron-right"></i> about </a>
                <a href="#services"> <i class="fas fa-chevron-right"></i> services </a>
                <a href="#doctors"> <i class="fas fa-chevron-right"></i> doctors </a>
                <a href="#appointment"> <i class="fas fa-chevron-right"></i> appointment </a>
                <a href="#review"> <i class="fas fa-chevron-right"></i> review </a>
                <a href="#blogs"> <i class="fas fa-chevron-right"></i> blogs </a>
            </div>

            <div class="box">
                <h3>our services</h3>
                <a href="#"> <i class="fas fa-chevron-right"></i> dental care </a>
                <a href="#"> <i class="fas fa-chevron-right"></i> message therapy </a>
                <a href="#"> <i class="fas fa-chevron-right"></i> cardioloty </a>
                <a href="#"> <i class="fas fa-chevron-right"></i> diagnosis </a>
                <a href="#"> <i class="fas fa-chevron-right"></i> ambulance service </a>
            </div>

            <div class="box">
                <h3>appointment info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +94788185568 </a>
                <a href="#"> <i class="fas fa-phone"></i> +94750802780</a>
                <a href="#"> <i class="fas fa-envelope"></i> sumaiyah.lk@gmail.com </a>
                <a href="#"> <i class="fas fa-map-marker-alt"></i> 20500, Kandy, Sri lanka </a>
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
                <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
                <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            </div>

        </div>

        <div class="credit"> Copyright 2024 © <span>sumaiyahAshraf</span> | all rights reserved | Powered by vtaDiplomaStudent </div>

    </section>

    <!-- footer section ends -->

    <!-- js file link  -->
    <script src="js/script.js"></script>

</body>

</html>